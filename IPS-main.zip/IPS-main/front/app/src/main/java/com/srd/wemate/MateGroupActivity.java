package com.srd.wemate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.srd.wemate.dto.MateGroupAddRequestDto;
import com.srd.wemate.dto.MateGroupDeleteRequestDto;
import com.srd.wemate.dto.MateGroupResponseDto;
import com.srd.wemate.dto.MateGroupSaveRequestDto;
import com.srd.wemate.dto.PostsSaveRequestDto;
import com.srd.wemate.model.MateGroup;
import com.srd.wemate.model.Profile;
import com.srd.wemate.retrofit.MateGroupApi;
import com.srd.wemate.retrofit.PostsApi;
import com.srd.wemate.retrofit.ProfileApi;
import com.srd.wemate.retrofit.RetrofitService;

import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MateGroupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mate_group);

        Button registerBtn = (Button) findViewById(R.id.btnRegisterMateGroup);
        Button addMateBtn = (Button) findViewById(R.id.btnAddMate);
        Button deleteMateBtn = (Button) findViewById(R.id.btnDeleteMate);
        Button deleteBtn = (Button) findViewById(R.id.btnDeleteMateGroup);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MateGroupActivity.this, "등록되었습니다", Toast.LENGTH_SHORT).show();

                // for test
                Profile q1 = new Profile();  // 매칭 버튼 누른 사람 id 가져오기
                q1.setId("t1");
                Profile q2 = new Profile();  // 채팅하고있는 사람 id 가져오기
                q2.setId("t2");

                RetrofitService retrofitService = new RetrofitService();

                // 등록
                ProfileApi profileApi = retrofitService.getRetrofit().create(ProfileApi.class);
                profileApi.save(q1)
                        .enqueue(new Callback<Profile>() {
                            @Override
                            public void onResponse(Call<Profile> call, Response<Profile> response) {
                                Log.i("save","Response성공:"+response.body().toString());
                            }

                            @Override
                            public void onFailure(Call<Profile> call, Throwable t) {
                                //Log.i("save","Response실패:"+t);
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });

                profileApi.save(q2)
                        .enqueue(new Callback<Profile>() {
                            @Override
                            public void onResponse(Call<Profile> call, Response<Profile> response) {
                                Log.i("save","Response성공:"+response.body().toString());
                            }

                            @Override
                            public void onFailure(Call<Profile> call, Throwable t) {
                                //Log.i("save","Response실패:"+t);
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });

                MateGroupApi mateGroupApi = retrofitService.getRetrofit().create(MateGroupApi.class);

                // generate group
                MateGroupSaveRequestDto requestDto = new MateGroupSaveRequestDto();

                mateGroupApi.save(requestDto).enqueue(new Callback<Integer>() {
                    @Override
                    public void onResponse(Call<Integer> call, Response<Integer> response) {
                        //assert response.body() != null;
                        Log.i("save","Response성공:"+ response.body());   // gid

                        int gid = response.body();

                        // insert group users
                        MateGroupAddRequestDto addrequestDto = new MateGroupAddRequestDto("t1");

                        mateGroupApi.addMate(gid, addrequestDto).enqueue(new Callback<Integer>() {
                            @Override
                            public void onResponse(Call<Integer> call, Response<Integer> response) {
                                //assert response.body() != null;
                                Log.i("save","Response성공:"+ response.body());

                            }

                            @Override
                            public void onFailure(Call<Integer> call, Throwable t) {
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });

                        MateGroupAddRequestDto addrequestDto2 = new MateGroupAddRequestDto("t2");

                        mateGroupApi.addMate(gid, addrequestDto2).enqueue(new Callback<Integer>() {
                            @Override
                            public void onResponse(Call<Integer> call, Response<Integer> response) {
                                //assert response.body() != null;
                                Log.i("save","Response성공:"+ response.body());

                            }

                            @Override
                            public void onFailure(Call<Integer> call, Throwable t) {
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });
                    }

                    @Override
                    public void onFailure(Call<Integer> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });


            }
        });

        addMateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MateGroupActivity.this, "등록되었습니다", Toast.LENGTH_SHORT).show();

                RetrofitService retrofitService = new RetrofitService();
                MateGroupApi mateGroupApi = retrofitService.getRetrofit().create(MateGroupApi.class);

                Profile a2 = new Profile();
                a2.setId("a2");

                ProfileApi profileApi = retrofitService.getRetrofit().create(ProfileApi.class);
                profileApi.save(a2)
                        .enqueue(new Callback<Profile>() {
                            @Override
                            public void onResponse(Call<Profile> call, Response<Profile> response) {
                                Log.i("save","Response성공:"+response.body());
                            }

                            @Override
                            public void onFailure(Call<Profile> call, Throwable t) {
                                //Log.i("save","Response실패:"+t);
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });

                MateGroupAddRequestDto requestDto = new MateGroupAddRequestDto("a1");

                mateGroupApi.addMate(24, requestDto).enqueue(new Callback<Integer>() {
                    @Override
                    public void onResponse(Call<Integer> call, Response<Integer> response) {
                        //assert response.body() != null;
                        Log.i("save","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Integer> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

        deleteMateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RetrofitService retrofitService = new RetrofitService();
                MateGroupApi mateGroupApi = retrofitService.getRetrofit().create(MateGroupApi.class);

                MateGroupDeleteRequestDto requestDto = new MateGroupDeleteRequestDto("q1");
                mateGroupApi.deleteMate(24, requestDto)
                        .enqueue(new Callback<Integer>() {
                            @Override
                            public void onResponse(Call<Integer> call, Response<Integer> response) {
                                Log.i("save","Response성공:"+response.body());
                            }

                            @Override
                            public void onFailure(Call<Integer> call, Throwable t) {
                                //Log.i("save","Response실패:"+t);
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });
            }
        });

    }
}