package com.srd.wemate.dto;

public class PostsSaveRequestDto {

    private String content;
    private String author;
    private boolean pin;

    public PostsSaveRequestDto(String content, String author, boolean pin) {
        this.content = content;
        this.author = author;
        this.pin = pin;
    }

//    public Post toEntity() {
//        Post post = new Post(content, author, pin);
//        return post;
//    }

    public PostsSaveRequestDto() {
    }

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }

    public boolean getPin() { return pin; }
}
