package com.srd.wemate;

import static com.srd.wemate.KakaoLoginActivity.kakao_id;
import static com.srd.wemate.NaverLoginActivity.naver_id;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    Button imageButton;
    Button chat_btn;


    // naver login
    ImageButton naverloginbtn;
    ImageButton kakaologinbtn;

    public static String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton = (Button) findViewById(R.id.btn1);
        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), UserProfileActivity.class);
                startActivity(intent);
            }
        });

        naverloginbtn = (ImageButton) findViewById(R.id.btnNaverlogin);
        naverloginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), NaverLoginActivity.class);
                startActivity(intent);
            }
        });

        kakaologinbtn = (ImageButton) findViewById(R.id.btnKakaologin);
        kakaologinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),KakaoLoginActivity.class);
                startActivity(intent);
            }
        });

        if(kakao_id != null){
            id=kakao_id;
        }
        else if(naver_id != null){
            id=naver_id;
        }

        // 게시판 글 작성 테스트용 코드
        Button postbtn = (Button) findViewById(R.id.btn2);
        postbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PostsActivity.class);
                startActivity(intent);
            }
        });

        // 메이트 그룹 만들기 테스트용 코드
        Button matebtn = (Button) findViewById(R.id.btnMate);
        matebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MateGroupActivity.class);
                startActivity(intent);
            }
        });

        //채팅
        chat_btn = (Button) findViewById(R.id.btn3);
        chat_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
                startActivity(intent);
            }
        });

        Button btnRule = (Button) findViewById(R.id.btnRule);
        btnRule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RuleActivity.class);
                startActivity(intent);
            }
        });

    }
}
