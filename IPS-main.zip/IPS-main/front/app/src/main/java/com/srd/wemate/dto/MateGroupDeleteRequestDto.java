package com.srd.wemate.dto;


import com.srd.wemate.model.Profile;

public class MateGroupDeleteRequestDto {

	private String userId;

	public MateGroupDeleteRequestDto(String userId) {
		this.userId = userId;
	}

}
