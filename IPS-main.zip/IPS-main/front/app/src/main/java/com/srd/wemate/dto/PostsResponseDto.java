package com.srd.wemate.dto;

public class PostsResponseDto {

    private Long id;
    private String content;
    private String author;
    private boolean pin;

//    public PostsResponseDto(Post entity) {
//        this.id = entity.getId();
//        this.content = entity.getContent();
//        this.author = entity.getAuthor();
//        this.pin = entity.isPin();
//    }

    public Long getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isPin() {
        return pin;
    }
}
