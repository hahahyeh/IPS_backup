package com.srd.wemate.dto;


import com.srd.wemate.model.MateGroup;

public class RuleSaveRequestDto {

	private String content;
	private int groupID;

	public RuleSaveRequestDto(String content, int groupID) {
		this.content = content;
		this.groupID = groupID;
	}
	
}
