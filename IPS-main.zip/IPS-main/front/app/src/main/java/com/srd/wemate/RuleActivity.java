package com.srd.wemate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.srd.wemate.dto.PostsSaveRequestDto;
import com.srd.wemate.dto.RuleSaveRequestDto;
import com.srd.wemate.dto.RuleUpdateRequestDto;
import com.srd.wemate.retrofit.PostsApi;
import com.srd.wemate.retrofit.RetrofitService;
import com.srd.wemate.retrofit.RuleApi;

import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RuleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rule);

        Button btnSave = (Button) findViewById(R.id.btnSaveRule);
        Button btnUpdate = (Button) findViewById(R.id.btnUpdateRule);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RetrofitService retrofitService = new RetrofitService();
                RuleApi ruleApi = retrofitService.getRetrofit().create(RuleApi.class);

                RuleSaveRequestDto requestDto = new RuleSaveRequestDto("test", 26);

                ruleApi.save(requestDto).enqueue(new Callback<Integer>() {
                    @Override
                    public void onResponse(Call<Integer> call, Response<Integer> response) {
                        //assert response.body() != null;
                        Log.i("save","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Integer> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RetrofitService retrofitService = new RetrofitService();
                RuleApi ruleApi = retrofitService.getRetrofit().create(RuleApi.class);

                RuleUpdateRequestDto requestDto = new RuleUpdateRequestDto("updated");

                System.out.println(requestDto.getContent());
                ruleApi.update(1, requestDto).enqueue(new Callback<Integer>() {
                    @Override
                    public void onResponse(Call<Integer> call, Response<Integer> response) {
                        //assert response.body() != null;
                        Log.i("save","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Integer> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });
    }
}