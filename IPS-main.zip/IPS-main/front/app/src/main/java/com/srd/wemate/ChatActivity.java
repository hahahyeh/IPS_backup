package com.srd.wemate;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.srd.wemate.model.ChatData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;

public class ChatActivity extends AppCompatActivity {
    ImageButton send_btn;
    Button id_send;
    EditText msg_text, id_input;
    String msg_str,id_str;
    FirebaseDatabase database;
    DatabaseReference myRef;
    ChatData chatData;
    String id; //카카오 or 네이버 로그인
    ArrayList<ChatData> chatDataArrayList;
    String datetime;
    //ChatAdapter chatAdapter;

    private static final String TAG = "ChatActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        send_btn = (ImageButton) findViewById(R.id.btn_send);
        id_send = (Button) findViewById(R.id.id_send);
        database = FirebaseDatabase.getInstance();
        chatDataArrayList= new ArrayList<>();

        Log.i(TAG, "id:"+id);

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String id_string = dataSnapshot.child("i_id").getValue(String.class);
                String msg_string = dataSnapshot.child("msg").getValue(String.class);
                Log.i("","id출력:"+id_string+"  메세지출력:"+msg_string);
                if(id==id_string){ // LEFT_CONTENT = 0(상대방), RIGHT_CONTENT = 1 (나)
                    chatData.setViewType(1);
                }
                else if(id!=id_string){
                    chatData.setViewType(0);
                }
                chatData.setI_id(id_string);
                chatData.setU_id("아직 안넣음"); //룸메 검색 게시판에서 채팅을 원하는 사람을 클릭하면 그 사람의 아이디값 가져와야 함
                chatData.setContent(msg_string);
                chatData.setU_img(123123l); //아마 long값? 어떻게 넣을지 확인
                chatData.setTime(datetime);
                chatDataArrayList.add(chatData);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };





        id_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id_input=(EditText) findViewById(R.id.id_input);
                id_str = id_input.getText().toString();


            }
        });

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                msg_text = (EditText) findViewById(R.id.editChat);
                msg_str = msg_text.getText().toString();
                chatData = new ChatData(id_str,msg_str);

                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                datetime = dateFormat.format(calendar.getTime());

                myRef = database.getReference("message").child(datetime);

                Hashtable<String, String> value
                        = new Hashtable<String, String>();
                value.put("i_id",id_str);
                value.put("msg",msg_str);
                myRef.setValue(value);
                myRef.addValueEventListener(valueEventListener);
                msg_text.setText("");
            }
        });


    }
}