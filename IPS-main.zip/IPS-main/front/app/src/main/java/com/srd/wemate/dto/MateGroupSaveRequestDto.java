package com.srd.wemate.dto;

import com.srd.wemate.model.MateGroup;
import com.srd.wemate.model.Profile;

import java.util.HashSet;
import java.util.Set;

public class MateGroupSaveRequestDto {

//	private Set<Profile> users;
//
//	public MateGroupSaveRequestDto(Profile user1, Profile user2) {
//
//		users = new HashSet<Profile>();
//		users.add(user1);
//		users.add(user2);
//	}

	public MateGroupSaveRequestDto() {

	}
	
//	public MateGroup toEntity() {
//		return MateGroup.builder().users(users).build();
//	}
}
