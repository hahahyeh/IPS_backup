package com.srd.wemate.retrofit;

import com.srd.wemate.dto.MateGroupAddRequestDto;
import com.srd.wemate.dto.PostsSaveRequestDto;
import com.srd.wemate.dto.PostsUpdateRequestDto;
import com.srd.wemate.dto.RuleSaveRequestDto;
import com.srd.wemate.dto.RuleUpdateRequestDto;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface RuleApi {

    @POST("/rule")
    Call<Integer> save(@Body RuleSaveRequestDto requestDto);

    @PUT("/rule/{id}")
    Call<Integer> update(@Path("id") int id, @Body RuleUpdateRequestDto requestDto);

}
