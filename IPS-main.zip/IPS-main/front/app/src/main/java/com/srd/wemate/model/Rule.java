package com.srd.wemate.model;


public class Rule {

	private int gid;
	private String content;
	
	@Override
    public String toString() {
        return "Rule{" +
                "gid" + gid +
                ", content=" + content +
                '}';
    }

	public Rule(int gid, String content) {
		this.gid = gid;
		this.content = content;
	}
	
	public void update(String content) {
        this.content = content;
    }
}
