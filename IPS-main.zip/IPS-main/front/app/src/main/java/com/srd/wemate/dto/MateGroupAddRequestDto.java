package com.srd.wemate.dto;

import com.srd.wemate.model.Profile;

import java.util.Set;

public class MateGroupAddRequestDto {

//	private Profile user;
//
//	public MateGroupAddRequestDto(Profile user) {
//		this.user = user;
//	}

	private String userId;

	public MateGroupAddRequestDto(String userId) {
		this.userId = userId;
	}

//	public Profile getProfile() {
//		Profile profile = repository.findById(userId).orElseThrow(() ->
//				new IllegalArgumentException("해당 게시글이 없습니다. id=" + userId));
//
//		return profile;
//	}
	
}
