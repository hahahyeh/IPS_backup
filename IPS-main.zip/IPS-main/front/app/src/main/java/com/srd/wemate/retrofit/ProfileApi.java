package com.srd.wemate.retrofit;


import com.srd.wemate.dto.PostsUpdateRequestDto;
import com.srd.wemate.dto.ProfileUpdateRequestDto;
import com.srd.wemate.model.Profile;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface ProfileApi {

    @GET("/profile/get-all")
    Call<List<Profile>> getAllProfile();

    @POST("/profile/save")
    Call<Profile> save(@Body Profile profile);

    @PUT("/profile/{id}")
    Call<String> update(@Path("id") String id, @Body ProfileUpdateRequestDto requestDto);

}
