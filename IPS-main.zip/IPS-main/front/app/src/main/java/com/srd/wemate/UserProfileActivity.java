package com.srd.wemate;
import androidx.appcompat.app.AppCompatActivity;
        import android.os.Bundle;
import android.util.Log;
import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.srd.wemate.dto.ProfileUpdateRequestDto;
import com.srd.wemate.model.Profile;
import com.srd.wemate.retrofit.ProfileApi;
import com.srd.wemate.retrofit.RetrofitService;

import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserProfileActivity extends AppCompatActivity {
    ArrayAdapter<CharSequence> adspin1, adspin2;
    String choice_do="";
    String choice_se="";
    private Spinner spinner_term;
    private TextView tv_result;

    static Profile profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        EditText inputEditName = findViewById(R.id.name);
        EditText inputEditTitle = findViewById(R.id.title);
        RadioButton inputEditGender1 = findViewById(R.id.radio_women);
        RadioButton inputEditSmoke1 = findViewById(R.id.radio_smoking);
        EditText inputEditAge = findViewById(R.id.age);
        RadioButton rbpet = findViewById(R.id.radio_pet);
        EditText inputEditPet = findViewById(R.id.pet);

        final Spinner spin1 = (Spinner)findViewById(R.id.spinner);
        final Spinner spin2 = (Spinner)findViewById(R.id.spinner2);
        Button btn_refresh = (Button)findViewById(R.id.btn_refresh);


        adspin1 = ArrayAdapter.createFromResource(this, R.array.spinner_do, android.R.layout.simple_spinner_dropdown_item);

        adspin1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spin1.setAdapter(adspin1);
        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (adspin1.getItem(i).equals("강남구")) {
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gangnam, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) { //아무것도 선택안될시 자동완성
                        }
                    });
                } else if (adspin1.getItem(i).equals("강동구")) {
                    choice_do = "강동구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gangdong, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("강북구")) {
                    choice_do = "강북구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gangbuk, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("강서구")) {
                    choice_do = "강서구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gangseo, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("관악구")) {
                    choice_do = "관악구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gwanak, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("광진구")) {
                    choice_do = "광진구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_gwangjin, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("구로구")) {
                    choice_do = "구로구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_guro, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("금천구")) {
                    choice_do = "금천구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_geumcheon, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("노원구")) {
                    choice_do = "노원구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_nowon, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("도봉구")) {
                    choice_do = "도봉구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_dobong, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("동대문구")) {
                    choice_do = "동대문구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_dongdaemun, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("동작구")) {
                    choice_do = "동작구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_dongjag, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("마포구")) {
                    choice_do = "마포구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_mapo, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("서대문구")) {
                    choice_do = "서대문구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_seodaemun, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("서초구")) {
                    choice_do = "서초구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_seocho, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("성동구")) {
                    choice_do = "성동구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_seongdong, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("성북구")) {
                    choice_do = "성북구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_seongbuk, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("송파구")) {
                    choice_do = "송파구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_songpa, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("양천구")) {
                    choice_do = "양천구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_yangcheon, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("영등포구")) {
                    choice_do = "영등포구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_yeongdeungpo, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("용산구")) {
                    choice_do = "용산구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_yongsan, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("은평구")) {
                    choice_do = "은평구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_eunpyeong, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("종로구")) {
                    choice_do = "종로구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_jongno, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("중구")) {
                    choice_do = "중구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_jung, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else if (adspin1.getItem(i).equals("중랑구")) {
                    choice_do = "중랑구";
                    adspin2 = ArrayAdapter.createFromResource(UserProfileActivity.this, R.array.spinner_region_seoul_jungnanggu, android.R.layout.simple_spinner_dropdown_item);
                    adspin2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spin2.setAdapter(adspin2);
                    spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            choice_se = adspin2.getItem(i).toString();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        //버튼 클릭시 이벤트
        btn_refresh.setOnClickListener(view -> {
            Toast.makeText(UserProfileActivity.this, "저장되었습니다", Toast.LENGTH_SHORT).show();

            String name = inputEditName.getText().toString();
            String title = inputEditTitle.getText().toString();
            System.out.println("title" + title);

            String gender;
            if (inputEditGender1.isChecked()) {
                gender = "female";
            } else {
                gender = "male";
            }
            System.out.println("gender" + gender);

            boolean smoke;
            if (inputEditSmoke1.isChecked()) {
                smoke = true;
            } else {
                smoke = false;
            }
            System.out.println("smoke" + smoke);

            int age = Integer.parseInt(inputEditAge.getText().toString());

            String pet;
            if (rbpet.isChecked()) {
                pet = inputEditPet.getText().toString();
            } else {
                pet = "null";
            }


            RetrofitService retrofitService = new RetrofitService();
            ProfileApi profileApi = retrofitService.getRetrofit().create(ProfileApi.class);

            profile = new Profile();
            profile.setName(name);
            profile.setTitle(title);
            profile.setGender(gender);
            profile.setSmoke(smoke);
            profile.setAge(age);
            profile.setPet(pet);

            profileApi.save(profile)
                    .enqueue(new Callback<Profile>() {
                        @Override
                        public void onResponse(Call<Profile> call, Response<Profile> response) {
                            Log.i("save","Response성공:"+response.body().toString());
                        }

                        @Override
                        public void onFailure(Call<Profile> call, Throwable t) {
                            //Log.i("save","Response실패:"+t);
                            Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                        }
                    });
        });

        Spinner spinner3 = (Spinner) findViewById(R.id.spinner_term);
        tv_result = (TextView)findViewById(R.id.tv_result);

        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                tv_result.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button btnUpdate = (Button)findViewById(R.id.btn_updateProfile);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(UserProfileActivity.this, "수정되었습니다", Toast.LENGTH_SHORT).show();

                String name = inputEditName.getText().toString();
                String title = inputEditTitle.getText().toString();
                System.out.println("title" + title);

                String gender;
                if (inputEditGender1.isChecked()) {
                    gender = "female";
                } else {
                    gender = "male";
                }
                System.out.println("gender" + gender);

                boolean smoke;
                if (inputEditSmoke1.isChecked()) {
                    smoke = true;
                } else {
                    smoke = false;
                }
                System.out.println("smoke" + smoke);

                int age = Integer.parseInt(inputEditAge.getText().toString());

                String pet;
                if (rbpet.isChecked()) {
                    pet = inputEditPet.getText().toString();
                } else {
                    pet = "null";
                }


                RetrofitService retrofitService = new RetrofitService();
                ProfileApi profileApi = retrofitService.getRetrofit().create(ProfileApi.class);

                ProfileUpdateRequestDto requestDto = new ProfileUpdateRequestDto();
                requestDto.setName(name);
                requestDto.setTitle(title);
                requestDto.setGender(gender);
                requestDto.setSmoke(smoke);
                requestDto.setAge(age);
                requestDto.setPet(pet);

                profileApi.update("1223", requestDto)
                        .enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                Log.i("save","Response성공:"+response.body().toString());
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                //Log.i("save","Response실패:"+t);
                                Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                            }
                        });
            }
        });
    }
}
