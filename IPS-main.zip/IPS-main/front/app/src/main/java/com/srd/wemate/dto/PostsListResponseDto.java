package com.srd.wemate.dto;


public class PostsListResponseDto {
	
	private Long id;
	private String content;
	private String author;
	private boolean pin;
	//private LocalDateTime modifiedDate;
	
//	public PostsListResponseDto(Post entity) {
//		this.id = entity.getId();
//		this.content = entity.getContent();
//		this.author = entity.getAuthor();
//		this.pin = entity.isPin();
//		//this.modifiedDate = entity.getModifiedDate();
//	}

	@Override
	public String toString() {
		return "Posts{" +
				"id=" + id +
				", content=" + content +
				", author=" + author +
				", pin=" + pin;
	}

}
