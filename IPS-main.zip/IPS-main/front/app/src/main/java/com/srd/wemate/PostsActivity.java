package com.srd.wemate;



import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.srd.wemate.dto.PostsListResponseDto;
import com.srd.wemate.dto.PostsSaveRequestDto;
import com.srd.wemate.dto.PostsUpdateRequestDto;
import com.srd.wemate.model.Profile;
import com.srd.wemate.retrofit.PostsApi;
import com.srd.wemate.retrofit.RetrofitService;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PostsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts);

        EditText tvContent = (EditText) findViewById(R.id.tv_PostContent);
        CheckBox cbPin = (CheckBox) findViewById(R.id.cb_PostsPin);
        Button btnSave = (Button) findViewById(R.id.btn_PostSave);
        Button btnUpdate = (Button) findViewById(R.id.btn_PostUpdate);
        Button btnDelete = (Button) findViewById(R.id.btn_PostDelete);
        Button btnLoad = (Button) findViewById(R.id.btn_PostLoad);

        // 테스트용 코드
        Profile testprofile = new Profile();
        testprofile.setName("testname");

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PostsActivity.this, "저장되었습니다", Toast.LENGTH_SHORT).show();

                String content = tvContent.getText().toString();
                String author = testprofile.getName(); // 여기 수정 필요 (테스트용)
                //String author = profile.getName();
                boolean pin = false;
                if (cbPin.isChecked()) {
                    pin = true;
                }

                RetrofitService retrofitService = new RetrofitService();
                PostsApi postsApi = retrofitService.getRetrofit().create(PostsApi.class);

                PostsSaveRequestDto requestDto = new PostsSaveRequestDto(content, author, pin);

                postsApi.save(requestDto).enqueue(new Callback<Long>() {
                    @Override
                    public void onResponse(Call<Long> call, Response<Long> response) {
                        //assert response.body() != null;
                        Log.i("save","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Long> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PostsActivity.this, "수정되었습니다", Toast.LENGTH_SHORT).show();

                String content = tvContent.getText().toString();
                boolean pin = false;
                if (cbPin.isChecked()) {
                    pin = true;
                }

                RetrofitService retrofitService = new RetrofitService();
                PostsApi postsApi = retrofitService.getRetrofit().create(PostsApi.class);

                PostsUpdateRequestDto requestDto = new PostsUpdateRequestDto(content, pin);

                // 테스트용 코드 -> id 가져오는 코드 구현 필요
                Long postID = 2L;

                postsApi.update(postID, requestDto).enqueue(new Callback<Long>() {
                    @Override
                    public void onResponse(Call<Long> call, Response<Long> response) {
                        //assert response.body() != null;
                        Log.i("update","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Long> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PostsActivity.this, "삭제되었습니다", Toast.LENGTH_SHORT).show();

                RetrofitService retrofitService = new RetrofitService();
                PostsApi postsApi = retrofitService.getRetrofit().create(PostsApi.class);

                // 테스트용 코드 -> id 가져오는 코드 구현 필요
                Long postID = 2L;

                postsApi.delete(postID).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        //assert response.body() != null;
                        Log.i("delete","Response성공:"+ response.body());

                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PostsActivity.this, "loading", Toast.LENGTH_SHORT).show();

                RetrofitService retrofitService = new RetrofitService();
                PostsApi postsApi = retrofitService.getRetrofit().create(PostsApi.class);


                postsApi.findAllDesc().enqueue(new Callback<List<PostsListResponseDto>>() {
                    @Override
                    public void onResponse(Call<List<PostsListResponseDto>> call, Response<List<PostsListResponseDto>> response) {
                        //assert response.body() != null;
                        Log.i("delete","Response성공:"+ response.body());
                    }

                    @Override
                    public void onFailure(Call<List<PostsListResponseDto>> call, Throwable t) {
                        Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE,"에러",t);
                    }
                });
            }
        });

    }
}