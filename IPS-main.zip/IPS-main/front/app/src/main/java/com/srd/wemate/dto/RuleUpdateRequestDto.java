package com.srd.wemate.dto;

public class RuleUpdateRequestDto {


	private String content;

	public RuleUpdateRequestDto(String content) {
		this.content = content;
	}

	public String getContent() {
		return this.content;
	}
}
